# quick_encrypt/__init__.py
from .core import generate_key, encrypt_message, decrypt_message
